# CLPR website prototype

Project website prototype for **CLPR** (“Clipper”), the bridgeless Cross Ledger Protocol, an
[LF Decentralized Trust](https://www.lfdecentralizedtrust.org/) Lab.

> Prototype only. This is not yet an official CLPR property. See [Before launch](#before-launch).

## Stack

Next.js 16 (App Router) · React 19 · TypeScript (strict) · Tailwind CSS 4 · shadcn/ui-style components · pnpm

## Getting started

```bash
pnpm install
pnpm dev           # http://localhost:3000
```

| Command          | What it does                       |
| ---------------- | ---------------------------------- |
| `pnpm dev`       | Development server                 |
| `pnpm build`     | Production build                   |
| `pnpm start`     | Serve the production build         |
| `pnpm lint`      | ESLint                             |
| `pnpm typecheck` | TypeScript, no emit                |

## Project structure

```
src/
  app/
    layout.tsx         Root layout, self-hosted fonts, metadata
    page.tsx           Home page (composes the sections below)
    not-found.tsx      404 page
    globals.css        Design tokens (shadcn semantic tokens + CLPR brand tokens)
    icon.svg           Favicon (CLPR spiral on the hero gradient)
    fonts/             Albert Sans (variable wght) and IBM Plex Mono, OFL-licensed
  components/
    ChannelDemo.tsx    Interactive 7-step walkthrough of a message crossing a Channel
    ClprMark.tsx       The CLPR spiral logo
    SpiralRibbon.tsx   Animated canvas ribbon tracing the spiral (hero and closing call to action)
    Comparison.tsx     Bridge vs. CLPR, switchable by aspect
    Glossary.tsx       Term explorer: search, categories, cross-linked definitions
    CopyCommand.tsx    Copyable shell command
    Hero.tsx  Walkthrough.tsx  Layers.tsx  Extensibility.tsx  Repositories.tsx
    Glossary.tsx  Roadmap.tsx  GetInvolved.tsx  SiteHeader.tsx  SiteFooter.tsx
    ui/                shadcn/ui-style primitives (button, input)
  content/
    site.ts            ALL copy and links. Edit content here, not in components.
  lib/utils.ts         cn(), format() for {placeholder} messages
public/logos/          Official LFDT, Hashgraph, Hedera and Hiero logos
```

## Editing content

Every user-facing string and link lives in `src/content/site.ts`, grouped by section. Copy is
based on the [CLPR lab proposal](https://github.com/LF-Decentralized-Trust/lab-proposals/issues/5),
the [LFDT-CLPR GitHub org](https://github.com/LFDT-CLPR) and
[hashgraph.com/clpr](https://hashgraph.com/clpr/).

## Design notes

The look follows the CLPR presentation on [hashgraph.com/clpr](https://hashgraph.com/clpr/).

- **Logo.** The CLPR spiral from the CLPR diagrams on hashgraph.com, in `ClprMark.tsx`.
- **Color.** Near-black ink (`#111116`) on white, pale periwinkle (`#E4ECFF`) for light panels,
  and three dark gradients built from indigo `#211271`, violet `#3F22D7` and magenta `#C82A80`:
  `bg-aurora` (hero), `bg-ember` (call to action) and `bg-dusk` (footer). Violet marks messages
  in transit; magenta is reserved for state proofs and verification.
- **Type.** hashgraph.com uses Styrene A, a licensed typeface. This site uses Albert Sans as a
  free stand-in: light weight with tight tracking for headlines, small uppercase tracked
  eyebrows above section headings. IBM Plex Mono only for real code: repository names and hashes.
  If a Styrene A web license is available, swap the font in `src/app/layout.tsx`.
- **Shape.** Pill buttons, rounded panels (`rounded-panel`), alternating white, periwinkle and
  dark sections.
- **Motion.** The spiral ribbon drifts slowly, the channel walkthrough autoplays, and a state
  proof travels between the ledgers in the comparison. With `prefers-reduced-motion` the ribbon
  is drawn as a still frame, the walkthrough waits for the visitor, and the proof stays put. The
  ribbon also pauses while it is off-screen.
- **Tokens.** All colors are defined once in `globals.css`. Components use semantic classes
  (`bg-card`, `text-muted-foreground`, `bg-mist`, `text-proof` …), never raw hex values.

## Before launch

- [ ] Confirm the CLPR spiral (`src/components/ClprMark.tsx`, `src/app/icon.svg`) against the
      official CLPR logo files from the LFDT / Hashgraph brand assets.
- [ ] Decide on the typeface: keep Albert Sans or license Styrene A.
- [ ] Replace the footer legal line (`footer.legal` in `site.ts`) with the official LFDT lab text.
- [ ] Confirm the roadmap phase marked “Now” (`roadmap.phases[].current`).
- [ ] Re-check statuses that will change: HIP-1535 and hiero-consensus-node PR #27029.
- [ ] Add community channels (Discord, mailing list, calls) once LFDT sets them up.
- [ ] Get logo usage confirmed with LFDT, Hashgraph, Hedera and Hiero brand guidelines.
- [ ] Set `metadataBase` and add an Open Graph image once the domain is known.

## License

Code: Apache-2.0. Fonts: SIL Open Font License (see `src/app/fonts/`). Logos are trademarks of
their respective owners and are used here to identify the projects.
