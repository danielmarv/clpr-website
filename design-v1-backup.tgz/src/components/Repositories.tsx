import { ArrowUpRight } from "lucide-react";

import { ClprMark } from "@/components/ClprMark";
import { CopyCommand } from "@/components/CopyCommand";
import { SectionHeading } from "@/components/SectionHeading";
import { repositories } from "@/content/site";

function repoPath(href: string): string {
  return href.replace(/^https:\/\/github\.com\//, "");
}

export function Repositories() {
  const [featured, ...rest] = repositories.items;

  return (
    <section aria-labelledby={repositories.id} className="mx-auto max-w-screen-xl px-5 sm:px-8">
      <div className="border-t border-border py-16 lg:py-24">
        <SectionHeading
          id={repositories.id}
          eyebrow={repositories.eyebrow}
          title={repositories.title}
          lead={repositories.lead}
        />

        <ul className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-2 lg:mt-16 lg:grid-cols-3">
          {/* The specification is the entry point, so it gets the large card. */}
          <li data-motion-reveal className="relative isolate overflow-hidden rounded-panel bg-night p-6 text-white sm:p-8 md:col-span-2 lg:col-span-1 lg:row-span-2">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -right-20 -top-24 -z-10 size-72 rounded-full bg-violet/45 blur-[90px]"
            />
            <ClprMark className="pointer-events-none absolute -bottom-8 -right-10 -z-10 h-44 text-white/[0.06]" />
            <div className="flex h-full flex-col">
              <div className="flex items-center gap-3">
                <span className="rounded-full bg-white/15 px-3 py-1 text-[0.78rem]">{repositories.featuredLabel}</span>
                <span className="text-[0.82rem] text-white/60">{featured.kind}</span>
              </div>
              <a
                href={featured.href}
                target="_blank"
                rel="noreferrer"
                className="group mt-8 inline-flex items-baseline gap-2 font-mono text-2xl font-medium after:absolute after:inset-0 after:content-['']"
              >
                {featured.name}
                <ArrowUpRight
                  className="size-5 translate-y-0.5 text-white/60 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-white"
                  aria-hidden="true"
                />
                <span className="sr-only">({repositories.openLabel})</span>
              </a>
              <p className="mt-4 text-night-text">{featured.body}</p>
              <CopyCommand
                command={repositories.clone.command}
                label={repositories.clone.label}
                copyLabel={repositories.clone.copy}
                copiedLabel={repositories.clone.copied}
                className="relative z-10 mt-8 lg:mt-auto"
              />
            </div>
          </li>

          {rest.map((repo) => (
            <li data-motion-reveal key={repo.name}>
              <a
                href={repo.href}
                target="_blank"
                rel="noreferrer"
                className="group flex h-full flex-col rounded-panel border border-border bg-card p-6 transition-[border-color,box-shadow,transform] duration-300 hover:-translate-y-1 hover:border-signal/30 hover:shadow-[0_24px_48px_-28px_rgb(63_34_215/0.45)] sm:p-7"
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="rounded-full bg-mist px-3 py-1 text-[0.78rem]">{repo.kind}</span>
                  <ArrowUpRight
                    className="size-5 text-muted-foreground transition-[color,transform] group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-signal"
                    aria-hidden="true"
                  />
                </div>
                <p className="mt-6 font-mono text-[1.05rem] font-medium">{repo.name}</p>
                <p className="mt-2 flex-1 text-[0.98rem] text-muted-foreground">{repo.body}</p>
                <p className="mt-6 truncate font-mono text-[0.75rem] text-muted-foreground">
                  github.com/{repoPath(repo.href)}
                </p>
                <span className="sr-only">({repositories.openLabel})</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
