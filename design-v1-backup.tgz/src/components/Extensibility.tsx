import { RadioTower, Server, ShieldCheck, type LucideIcon } from "lucide-react";

import { SectionHeading } from "@/components/SectionHeading";
import { extensibility } from "@/content/site";

// One icon per component, in the order they appear in the content.
const componentIcons: LucideIcon[] = [Server, RadioTower, ShieldCheck];

export function Extensibility() {
  return (
    <section aria-labelledby={extensibility.id} className="mx-auto max-w-screen-xl px-5 py-16 sm:px-8 lg:py-24">
      <SectionHeading
        id={extensibility.id}
        eyebrow={extensibility.eyebrow}
        title={extensibility.title}
        lead={extensibility.lead}
      />

      <div className="mt-14 grid gap-14 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-6">
          <ul className="space-y-10">
            {extensibility.components.map((component, index) => {
              const Icon = componentIcons[index] ?? Server;
              return (
                <li data-motion-reveal key={component.name} className="grid grid-cols-[3rem_1fr] gap-5 sm:grid-cols-[3.5rem_1fr] sm:gap-6">
                  <span className="flex size-12 items-center justify-center rounded-full bg-proof-wash text-proof sm:size-14">
                    <Icon className="size-6 sm:size-7" strokeWidth={1.75} aria-hidden="true" />
                  </span>
                  <div>
                    <h3 className="text-2xl font-normal leading-snug tracking-[-0.01em]">{component.name}</h3>
                    <p className="mt-2 text-muted-foreground">{component.body}</p>
                  </div>
                </li>
              );
            })}
          </ul>
          <p className="mt-10 max-w-[60ch] border-l-2 border-proof pl-4 text-[0.98rem] text-muted-foreground">
            {extensibility.footnote}
          </p>
        </div>

        <div className="lg:col-span-6">
          <div className="rounded-panel bg-mist p-6 sm:p-8">
            <h3 className="eyebrow">{extensibility.stepsTitle}</h3>
            <ol className="mt-6">
              {extensibility.steps.map((step, index) => (
                <li
                  key={step}
                  className="grid grid-cols-[2.25rem_1fr] gap-3 border-t border-foreground/10 py-3.5"
                >
                  <span className="pt-px text-[0.95rem] font-medium tabular-nums text-signal">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </section>
  );
}
