import Image from "next/image";
import Link from "next/link";

import { ClprMark } from "@/components/ClprMark";
import { footer, links, site } from "@/content/site";
import { format } from "@/lib/utils";

export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-dusk text-white/80">
      <div className="mx-auto max-w-screen-xl px-5 pb-10 pt-20 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Link href="/" aria-label={site.homeLabel} className="inline-flex items-center gap-3 text-white">
              <ClprMark className="h-7" />
              <span className="text-2xl font-medium tracking-[-0.01em]">{site.name}</span>
            </Link>
            <p className="mt-5 max-w-sm">{footer.labLine}</p>
            <a href={links.lfdt} target="_blank" rel="noreferrer" className="mt-5 inline-block">
              <Image
                src="/logos/lfdt-horizontal-white.svg"
                alt="LF Decentralized Trust"
                width={698.7}
                height={39.1}
                className="h-4 w-auto"
              />
            </a>
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:col-span-7">
            {footer.columns.map((column) => (
              <div key={column.title}>
                <h2 className="eyebrow text-white/60">{column.title}</h2>
                <ul className="mt-4 space-y-2.5">
                  {column.links.map((item) => (
                    <li key={item.label}>
                      <a
                        href={item.href}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[1rem] text-white transition-opacity hover:opacity-75"
                      >
                        {item.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        <div className="mt-16 flex flex-col gap-3 border-t border-white/15 pt-6 text-[0.85rem] text-white/70 md:flex-row md:justify-between md:gap-10">
          <p className="max-w-3xl">{format(footer.legal, { year })}</p>
          <p className="shrink-0">{footer.prototypeNote}</p>
        </div>
      </div>
    </footer>
  );
}
