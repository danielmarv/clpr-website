"use client";

import { useId, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { ChevronLeft, ChevronRight, Search, X } from "lucide-react";

import { SectionHeading } from "@/components/SectionHeading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { glossary } from "@/content/site";
import { cn, format } from "@/lib/utils";

type Term = (typeof glossary.terms)[number];
type Category = "all" | (typeof glossary.categories)[number];

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Longest names first, so "Data Message" wins over "Message".
const TERM_PATTERN = new RegExp(
  `\\b(${[...glossary.terms]
    .map((item) => item.term)
    .sort((a, b) => b.length - a.length)
    .map(escapeRegExp)
    .join("|")})(?:s)?\\b`,
  "gi",
);
const TERM_BY_NAME = new Map<string, Term>(glossary.terms.map((item) => [item.term.toLowerCase(), item]));

function mentionsIn(definition: string): string[] {
  return [...definition.matchAll(TERM_PATTERN)].flatMap((match) => {
    const name = TERM_BY_NAME.get(match[1].toLowerCase())?.term;
    return name ? [name] : [];
  });
}

/** Terms a definition mentions, plus terms whose definitions mention it. */
const RELATED = new Map<string, string[]>(
  glossary.terms.map((item) => {
    const outgoing = mentionsIn(item.definition);
    const incoming = glossary.terms.filter((other) => mentionsIn(other.definition).includes(item.term)).map((other) => other.term);
    return [item.term, [...new Set([...outgoing, ...incoming])].filter((name) => name !== item.term)];
  }),
);

function highlight(text: string, needle: string): ReactNode {
  if (!needle) return text;
  const parts = text.split(new RegExp(`(${escapeRegExp(needle)})`, "gi"));
  return parts.map((part, index) =>
    part.toLowerCase() === needle ? (
      <mark key={index} className="rounded-sm bg-signal-wash px-0.5 text-foreground">
        {part}
      </mark>
    ) : (
      part
    ),
  );
}

export function Glossary() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<Category>("all");
  const [selectedName, setSelectedName] = useState<string>(glossary.terms[0].term);
  const itemRefs = useRef(new Map<string, HTMLButtonElement>());
  const inputId = useId();

  const needle = query.trim().toLowerCase();
  const terms = glossary.terms.filter(
    (item) =>
      (category === "all" || item.category === category) &&
      (!needle || item.term.toLowerCase().includes(needle) || item.definition.toLowerCase().includes(needle)),
  );
  const selected = terms.find((item) => item.term === selectedName) ?? terms[0];
  const selectedIndex = selected ? terms.indexOf(selected) : -1;

  const choose = (name: string, focus = false) => {
    // Jumping to a term hidden by the filters clears them first.
    if (!terms.some((item) => item.term === name)) {
      setCategory("all");
      setQuery("");
    }
    setSelectedName(name);
    if (focus) itemRefs.current.get(name)?.focus();
  };

  const step = (offset: number) => {
    if (terms.length === 0) return;
    const next = terms[(selectedIndex + offset + terms.length) % terms.length];
    choose(next.term, true);
  };

  const onListKeyDown = (event: KeyboardEvent<HTMLUListElement>) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      step(1);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      step(-1);
    }
  };

  const detail = (compact: boolean) =>
    selected && (
      <TermDetail
        term={selected}
        index={selectedIndex}
        count={terms.length}
        compact={compact}
        onChoose={(name) => choose(name)}
        onStep={step}
      />
    );

  return (
    <section aria-labelledby={glossary.id} className="mx-auto max-w-screen-xl px-5 sm:px-8">
      <div className="rounded-panel bg-mist px-5 py-12 sm:px-10 sm:py-14 lg:px-14 lg:py-20">
        <SectionHeading id={glossary.id} eyebrow={glossary.eyebrow} title={glossary.title} lead={glossary.lead} />

        <div className="mt-10 grid gap-8 lg:mt-14 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-5">
            <label htmlFor={inputId} className="sr-only">
              {glossary.filterLabel}
            </label>
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                aria-hidden="true"
              />
              <Input
                id={inputId}
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder={glossary.filterPlaceholder}
                className="border-foreground/20 pl-10"
                aria-controls={`${inputId}-results`}
              />
            </div>

            <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Categories">
              {(["all", ...glossary.categories] as Category[]).map((item) => (
                <button
                  key={item}
                  type="button"
                  aria-pressed={category === item}
                  onClick={() => setCategory(item)}
                  className={cn(
                    "rounded-full border px-3.5 py-1.5 text-[0.85rem] transition-colors",
                    category === item
                      ? "border-foreground bg-foreground text-background"
                      : "border-foreground/15 bg-white/60 hover:border-foreground/40",
                  )}
                >
                  {item === "all" ? glossary.allLabel : item}
                </button>
              ))}
            </div>

            <div id={`${inputId}-results`} aria-live="polite" className="mt-6">
              {terms.length > 0 ? (
                <ul onKeyDown={onListKeyDown} className="flex flex-col gap-1 lg:max-h-[32rem] lg:overflow-y-auto lg:pr-1">
                  {terms.map((item) => {
                    const isSelected = item === selected;
                    return (
                      <li key={item.term}>
                        <button
                          ref={(element) => {
                            if (element) itemRefs.current.set(item.term, element);
                            else itemRefs.current.delete(item.term);
                          }}
                          type="button"
                          aria-current={isSelected ? "true" : undefined}
                          onClick={() => choose(item.term)}
                          className={cn(
                            "flex w-full items-center justify-between gap-4 rounded-lg px-4 py-3 text-left transition-colors",
                            isSelected ? "bg-night text-white" : "hover:bg-white/70",
                          )}
                        >
                          <span className="text-[1.02rem]">{highlight(item.term, needle)}</span>
                          <span className={cn("text-[0.75rem]", isSelected ? "text-white/60" : "text-muted-foreground")}>
                            {item.category}
                          </span>
                        </button>
                        {isSelected && <div className="mt-2 lg:hidden">{detail(true)}</div>}
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <div className="flex flex-col items-start gap-4 py-4">
                  <p className="text-muted-foreground">
                    {format(glossary.emptyState, { query: query.trim(), count: glossary.terms.length })}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setQuery("");
                      setCategory("all");
                    }}
                  >
                    <X />
                    {glossary.clearLabel}
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="hidden lg:col-span-7 lg:block">
            <div className="sticky top-28">{detail(false)}</div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TermDetail({
  term,
  index,
  count,
  compact,
  onChoose,
  onStep,
}: {
  term: Term;
  index: number;
  count: number;
  compact: boolean;
  onChoose: (name: string) => void;
  onStep: (offset: number) => void;
}) {
  const related = RELATED.get(term.term) ?? [];

  // Render the definition with every other glossary term as a link to its entry.
  const parts: ReactNode[] = [];
  let cursor = 0;
  for (const match of term.definition.matchAll(TERM_PATTERN)) {
    const target = TERM_BY_NAME.get(match[1].toLowerCase());
    const start = match.index ?? 0;
    if (!target || target.term === term.term) continue;
    parts.push(term.definition.slice(cursor, start));
    parts.push(
      <button
        key={start}
        type="button"
        onClick={() => onChoose(target.term)}
        className="text-white underline decoration-signal-glow/70 decoration-1 underline-offset-[5px] transition-colors hover:decoration-signal-glow"
      >
        {match[0]}
      </button>,
    );
    cursor = start + match[0].length;
  }
  parts.push(term.definition.slice(cursor));

  return (
    <article
      className={cn(
        "relative isolate overflow-hidden rounded-panel bg-night text-white",
        compact ? "p-5" : "min-h-[26rem] p-10",
      )}
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-28 -z-10 size-80 rounded-full bg-violet/40 blur-[90px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-32 -left-20 -z-10 size-72 rounded-full bg-magenta/25 blur-[90px]"
      />

      <div className="flex items-center justify-between gap-4">
        <p className="eyebrow text-white/60">{term.category}</p>
        <p className="text-[0.78rem] tabular-nums text-white/50">
          {format(glossary.position, { index: index + 1, count })}
        </p>
      </div>

      {!compact && (
        <h3 key={term.term} className="fade-up mt-8 text-[2.75rem] font-light leading-tight tracking-[-0.03em]">
          {term.term}
        </h3>
      )}
      <p
        key={`${term.term}-definition`}
        className={cn("fade-up font-light text-white/85", compact ? "mt-3 text-[1.05rem] leading-relaxed" : "mt-5 text-xl leading-relaxed")}
      >
        {parts}
      </p>

      {related.length > 0 && (
        <div className={compact ? "mt-5" : "mt-10"}>
          <p className="eyebrow text-white/50">{glossary.relatedLabel}</p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {related.map((name) => (
              <li key={name}>
                <button
                  type="button"
                  onClick={() => onChoose(name)}
                  className="rounded-full border border-white/20 px-3 py-1 text-[0.85rem] text-white/85 transition-colors hover:border-white hover:bg-white hover:text-night"
                >
                  {name}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {!compact && count > 1 && (
        <div className="mt-10 flex gap-2">
          <Button variant="inverse-outline" size="icon" className="border-white/30" onClick={() => onStep(-1)} aria-label={glossary.previous}>
            <ChevronLeft />
          </Button>
          <Button variant="inverse-outline" size="icon" className="border-white/30" onClick={() => onStep(1)} aria-label={glossary.next}>
            <ChevronRight />
          </Button>
        </div>
      )}
    </article>
  );
}
