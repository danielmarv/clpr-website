"use client";

import { animate, createAnimatable, createScope, stagger } from "animejs";
import { useEffect, useRef, type ReactNode } from "react";

/** A small client boundary keeps the page content server rendered. */
export function SiteMotion({ children }: { children: ReactNode }) {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = root.current;
    if (!element) return;

    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    let dispose = () => {};
    const setup = () => {
      dispose();
      dispose = () => {};
      if (preference.matches) return;

      const scope = createScope({ root });
      const listeners: (() => void)[] = [];
      const observer = new IntersectionObserver(
        (entries) => {
          const visible = entries.filter((entry) => entry.isIntersecting);
          if (!visible.length) return;
          scope.addOnce(() => {
            animate(visible.map((entry) => entry.target), {
              opacity: [0.35, 1],
              y: [24, 0],
              duration: 750,
              delay: stagger(70),
              ease: "out(4)",
            });
          });
          visible.forEach((entry) => observer.unobserve(entry.target));
        },
        { threshold: 0.12, rootMargin: "0px 0px -32px 0px" },
      );

      scope.add(() => {
        // Content is visible by default, including before hydration and without JS.
        // Only run the intro when the visitor is actually at the top of the page.
        if (window.scrollY < 80) {
          animate("[data-hero-reveal]", {
            opacity: [0, 1],
            y: [22, 0],
            duration: 900,
            delay: stagger(90, { start: 100 }),
            ease: "out(4)",
          });
          animate("[data-hero-art]", {
            opacity: [0, 1],
            scale: [0.94, 1],
            duration: 1400,
            delay: 200,
            ease: "out(3)",
          });
        }

        element.querySelectorAll<HTMLElement>("[data-motion-reveal]").forEach((target) => {
          observer.observe(target);
        });

        element.querySelectorAll<HTMLElement>('[data-slot="button"]').forEach((target) => {
          const motion = createAnimatable(target, { scale: 220, ease: "out(3)" });
          let hovered = false;
          let focused = false;
          const update = () => motion.scale(hovered || focused ? 1.035 : 1);
          const enter = (event: PointerEvent) => {
            if (event.pointerType !== "mouse") return;
            hovered = true;
            update();
          };
          const leave = () => { hovered = false; update(); };
          const focus = () => { focused = true; update(); };
          const blur = () => { focused = false; update(); };
          target.addEventListener("pointerenter", enter);
          target.addEventListener("pointerleave", leave);
          target.addEventListener("focus", focus);
          target.addEventListener("blur", blur);
          listeners.push(() => {
            target.removeEventListener("pointerenter", enter);
            target.removeEventListener("pointerleave", leave);
            target.removeEventListener("focus", focus);
            target.removeEventListener("blur", blur);
          });
        });
      });

      dispose = () => {
        observer.disconnect();
        listeners.forEach((remove) => remove());
        scope.revert();
      };
    };

    setup();
    preference.addEventListener("change", setup);
    return () => {
      preference.removeEventListener("change", setup);
      dispose();
    };
  }, []);

  return <div ref={root}>{children}</div>;
}
