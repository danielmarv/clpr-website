import { SectionHeading } from "@/components/SectionHeading";
import { roadmap } from "@/content/site";
import { cn } from "@/lib/utils";

export function Roadmap() {
  const currentIndex = Math.max(0, roadmap.phases.findIndex((phase) => phase.current));
  // The track fills up to the middle of the current phase.
  const progress = ((currentIndex + 0.5) / roadmap.phases.length) * 100;

  return (
    <section aria-labelledby={roadmap.id} className="mx-auto max-w-screen-xl px-5 py-16 sm:px-8 lg:py-24">
      <SectionHeading id={roadmap.id} eyebrow={roadmap.eyebrow} title={roadmap.title} lead={roadmap.lead} />

      <div className="relative mt-14 lg:mt-20">
        <div aria-hidden="true" className="absolute inset-x-0 top-[0.4375rem] hidden h-1 rounded-full bg-border lg:block">
          <div
            className="h-full rounded-full bg-gradient-to-r from-violet to-magenta"
            style={{ width: `${progress}%` }}
          />
        </div>

        <ol className="relative grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {roadmap.phases.map((phase, index) => {
            const isCurrent = index === currentIndex;
            const isPast = index < currentIndex;
            return (
              <li data-motion-reveal key={phase.name} className="flex flex-col">
                {/* Marker on the track */}
                <div className="mb-6 hidden h-[1.125rem] items-center justify-center lg:flex" aria-hidden="true">
                  {isCurrent ? (
                    <span className="relative flex size-[1.125rem]">
                      <span className="absolute inset-0 rounded-full bg-magenta/50 motion-safe:animate-ping" />
                      <span className="relative size-full rounded-full border-[3px] border-white bg-magenta shadow-[0_0_0_4px_var(--proof-wash)]" />
                    </span>
                  ) : (
                    <span
                      className={cn(
                        "size-3.5 rounded-full border-2",
                        isPast ? "border-violet bg-violet" : "border-line-strong bg-card",
                      )}
                    />
                  )}
                </div>

                <article
                  className={cn(
                    "relative isolate flex flex-1 flex-col overflow-hidden rounded-panel p-6 sm:p-7",
                    isCurrent
                      ? "bg-night text-white shadow-[0_30px_60px_-30px_rgb(200_42_128/0.55)]"
                      : isPast
                        ? "bg-mist"
                        : "border border-border bg-card",
                  )}
                >
                  {isCurrent && (
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute -right-16 -top-20 -z-10 size-60 rounded-full bg-magenta/35 blur-[80px]"
                    />
                  )}
                  <div className="flex items-start justify-between gap-4">
                    <span
                      className={cn(
                        "text-5xl font-extralight leading-none tracking-[-0.04em] tabular-nums",
                        isCurrent
                          ? "bg-gradient-to-r from-signal-glow to-proof-glow bg-clip-text text-transparent"
                          : "text-foreground/20",
                      )}
                      aria-hidden="true"
                    >
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    {isCurrent && (
                      <span className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-[0.78rem]">
                        <span className="size-1.5 rounded-full bg-proof-glow" aria-hidden="true" />
                        {roadmap.currentLabel}
                      </span>
                    )}
                  </div>

                  <p className={cn("eyebrow mt-8", isCurrent ? "text-white/60" : "text-muted-foreground")}>
                    {phase.period}
                  </p>
                  <h3 className="mt-2 text-2xl font-normal tracking-[-0.01em]">{phase.name}</h3>
                  <ul className="mt-5 space-y-3">
                    {phase.items.map((item) => (
                      <li
                        key={item}
                        className={cn(
                          "flex gap-3 text-[0.96rem] leading-relaxed",
                          isCurrent ? "text-night-text" : "text-muted-foreground",
                        )}
                      >
                        <span
                          className={cn(
                            "mt-[0.6rem] size-1.5 shrink-0 rounded-full",
                            isCurrent ? "bg-proof-glow" : "bg-line-strong",
                          )}
                          aria-hidden="true"
                        />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </article>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
