import Image from "next/image";
import { ArrowRight, Waypoints } from "lucide-react";

import { ChannelDemo } from "@/components/ChannelDemo";
import { SectionHeading } from "@/components/SectionHeading";
import { origins, walkthrough } from "@/content/site";

import styles from "./Walkthrough.module.css";

export function Walkthrough() {
  return (
    <section
      aria-labelledby={walkthrough.id}
      className="mx-auto max-w-screen-xl px-5 py-16 sm:px-8 lg:py-24"
    >
      <div className={styles.heading}>
        <div className="min-w-0">
          <p className={styles.eyebrow}>
            <Waypoints className="size-4" aria-hidden="true" />
            {walkthrough.eyebrow}
          </p>
          <SectionHeading
            id={walkthrough.id}
            title={walkthrough.title}
            lead={walkthrough.lead}
            className="mt-5"
          />
        </div>

        <div className={styles.routeAccent} aria-hidden="true">
          <div className={styles.routeNodes}>
            <span>A</span>
            <ArrowRight className="size-4" />
            <span>B</span>
            <ArrowRight className="size-4" />
            <span>A</span>
          </div>
          <p>One message. There and back.</p>
        </div>
      </div>

      <div className={styles.stage} data-motion-reveal>
        <ChannelDemo />
      </div>

      <div className={styles.origins}>
        <p className="max-w-[64ch] text-[0.94rem] leading-relaxed text-muted-foreground">
          {origins.text}
        </p>
        <ul className={styles.logos} aria-label="Contributing organizations">
          {origins.logos.map((logo) => (
            <li key={logo.name}>
              <a
                href={logo.href}
                target="_blank"
                rel="noreferrer"
                className="flex min-h-11 items-center opacity-75 transition-opacity hover:opacity-100 focus-visible:opacity-100"
              >
                <Image
                  src={logo.src}
                  alt={logo.name}
                  width={logo.width}
                  height={logo.height}
                  className={logo.className}
                />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
