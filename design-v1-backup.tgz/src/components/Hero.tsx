import Image from "next/image";

import { SpiralRibbon } from "@/components/SpiralRibbon";
import { Button } from "@/components/ui/button";
import { hero, links } from "@/content/site";

export function Hero() {
  return (
    <section className="hero-background text-white">
      <div className="hero-atmosphere" aria-hidden="true">
        <div className="hero-grid" />
        <div className="hero-orbit hero-orbit-outer" />
        <div className="hero-orbit hero-orbit-inner" />
        <div className="hero-horizon" />
      </div>
      <div className="relative z-10 mx-auto max-w-screen-xl px-5 pb-16 pt-32 sm:px-8 sm:pt-36 lg:pb-20 lg:pt-40">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-6">
          <div className="lg:col-span-6">
            <a
              data-hero-reveal
              href={links.lfdt}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2.5 text-sm text-white/75 transition-colors hover:text-white"
            >
              <span>{hero.labPrefix}</span>
              <Image
                src="/logos/lfdt-horizontal-white.svg"
                alt="LF Decentralized Trust"
                width={698.7}
                height={39.1}
                className="h-3.5 w-auto"
                priority
              />
            </a>

            <p data-hero-reveal className="eyebrow mt-10">{hero.eyebrow}</p>
            <h1 data-hero-reveal className="mt-5 max-w-[16ch] text-[clamp(2.6rem,6vw,4.5rem)] font-light leading-[1.1] tracking-[-0.04em] text-balance">
              {hero.title}
            </h1>
            <p data-hero-reveal className="mt-7 max-w-[58ch] text-lg leading-[1.75] text-white/85 sm:text-[1.2rem]">{hero.lead}</p>

            <div data-hero-reveal className="mt-10 flex flex-wrap gap-3">
              <Button asChild size="lg" variant="glass">
                <a href={hero.primaryCta.href} target="_blank" rel="noreferrer">
                  {hero.primaryCta.label}
                </a>
              </Button>
              <Button asChild size="lg" variant="inverse-outline">
                <a href={hero.secondaryCta.href}>{hero.secondaryCta.label}</a>
              </Button>
            </div>
          </div>

          <div data-hero-art className="-mx-5 sm:mx-0 lg:col-span-6 lg:-mr-10 xl:-mr-16">
            <SpiralRibbon />
          </div>
        </div>

        <dl className="mt-16 grid gap-x-10 border-t border-white/15 sm:grid-cols-3 lg:mt-20">
          {hero.facts.map((fact) => (
            <div data-hero-reveal key={fact.term} className="border-b border-white/15 py-5 sm:border-b-0">
              <dt className="eyebrow text-white/60">{fact.term}</dt>
              <dd className="mt-1.5 text-[1.05rem]">{fact.detail}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
