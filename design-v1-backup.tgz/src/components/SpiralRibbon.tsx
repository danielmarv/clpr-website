"use client";

import { useEffect, useRef } from "react";

import { cn } from "@/lib/utils";

/*
 * A twisting ribbon of light strands that traces the CLPR spiral, in the
 * spirit of the hero artwork on hashgraph.com/clpr. Drawn on a canvas so the
 * strands can drift slowly; a single still frame is drawn for visitors who
 * prefer reduced motion, and the loop pauses while the ribbon is off-screen.
 */

type Point = { x: number; y: number };
type Cubic = [Point, Point, Point, Point];

// Centerline of the spiral in a 600 × 440 box: the tail drops down on the
// left, sweeps along the bottom and up the right, then coils inward.
const VIEW = { width: 600, height: 440 };
const CENTERLINE: Cubic[] = [
  [{ x: 52, y: 40 }, { x: 46, y: 210 }, { x: 150, y: 368 }, { x: 305, y: 398 }],
  [{ x: 305, y: 398 }, { x: 455, y: 426 }, { x: 562, y: 338 }, { x: 566, y: 228 }],
  [{ x: 566, y: 228 }, { x: 570, y: 118 }, { x: 482, y: 56 }, { x: 398, y: 72 }],
  [{ x: 398, y: 72 }, { x: 318, y: 88 }, { x: 296, y: 190 }, { x: 356, y: 222 }],
  [{ x: 356, y: 222 }, { x: 410, y: 250 }, { x: 466, y: 202 }, { x: 444, y: 160 }],
  [{ x: 444, y: 160 }, { x: 428, y: 132 }, { x: 394, y: 140 }, { x: 392, y: 166 }],
];

const SAMPLES = 320;
const STRANDS = 90;
const CHUNKS = 48;
const SPARKS = 70;
const TWISTS = 3.2;

// Violet tail → magenta bowl → peach coil.
const COLOR_STOPS: { at: number; rgb: [number, number, number] }[] = [
  { at: 0, rgb: [120, 92, 255] },
  { at: 0.35, rgb: [214, 76, 196] },
  { at: 0.62, rgb: [255, 104, 150] },
  { at: 0.85, rgb: [255, 160, 132] },
  { at: 1, rgb: [255, 196, 170] },
];

function bezier([p0, p1, p2, p3]: Cubic, t: number): Point {
  const u = 1 - t;
  const a = u * u * u;
  const b = 3 * u * u * t;
  const c = 3 * u * t * t;
  const d = t * t * t;
  return { x: a * p0.x + b * p1.x + c * p2.x + d * p3.x, y: a * p0.y + b * p1.y + c * p2.y + d * p3.y };
}

/** Evenly spaced points (by arc length) along the centerline, with unit normals. */
function sampleCenterline(): { points: Point[]; normals: Point[] } {
  const dense: Point[] = [];
  for (const segment of CENTERLINE) {
    for (let step = 0; step < 120; step++) dense.push(bezier(segment, step / 120));
  }
  dense.push(CENTERLINE[CENTERLINE.length - 1][3]);

  const lengths = [0];
  for (let i = 1; i < dense.length; i++) {
    lengths.push(lengths[i - 1] + Math.hypot(dense[i].x - dense[i - 1].x, dense[i].y - dense[i - 1].y));
  }
  const total = lengths[lengths.length - 1];

  const points: Point[] = [];
  let cursor = 0;
  for (let i = 0; i < SAMPLES; i++) {
    const target = (i / (SAMPLES - 1)) * total;
    while (cursor < lengths.length - 2 && lengths[cursor + 1] < target) cursor++;
    const span = lengths[cursor + 1] - lengths[cursor] || 1;
    const t = (target - lengths[cursor]) / span;
    points.push({
      x: dense[cursor].x + (dense[cursor + 1].x - dense[cursor].x) * t,
      y: dense[cursor].y + (dense[cursor + 1].y - dense[cursor].y) * t,
    });
  }

  const normals = points.map((_, i) => {
    const prev = points[Math.max(0, i - 1)];
    const next = points[Math.min(points.length - 1, i + 1)];
    const dx = next.x - prev.x;
    const dy = next.y - prev.y;
    const length = Math.hypot(dx, dy) || 1;
    return { x: -dy / length, y: dx / length };
  });

  return { points, normals };
}

/** Ribbon half-width along the spiral: narrow tail, full bowl, tight coil. */
function ribbonWidth(s: number): number {
  return 4 + 44 * Math.pow(Math.sin(Math.PI * Math.min(1, s * 1.06)), 0.8) * (1 - 0.62 * s);
}

function colorAt(s: number, alpha: number): string {
  let index = 0;
  while (index < COLOR_STOPS.length - 2 && COLOR_STOPS[index + 1].at < s) index++;
  const from = COLOR_STOPS[index];
  const to = COLOR_STOPS[index + 1];
  const t = Math.min(1, Math.max(0, (s - from.at) / (to.at - from.at)));
  const [r, g, b] = from.rgb.map((value, channel) => Math.round(value + (to.rgb[channel] - value) * t));
  return `rgba(${r}, ${g}, ${b}, ${alpha.toFixed(3)})`;
}

// Deterministic pseudo-random numbers keep the sparks stable between renders.
function seeded(seed: number): () => number {
  let state = seed;
  return () => {
    state = (state * 16807) % 2147483647;
    return (state - 1) / 2147483646;
  };
}

export function SpiralRibbon({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;

    const { points, normals } = sampleCenterline();
    const widths = points.map((_, i) => ribbonWidth(i / (SAMPLES - 1)));
    const random = seeded(7);
    // Each strand gets its own amplitude and twist so the fibers braid and fan out.
    const strands = Array.from({ length: STRANDS }, (_, index) => ({
      phase: (index / STRANDS) * Math.PI * 2,
      amplitude: 0.55 + random() * 0.6,
      twist: TWISTS + (random() - 0.5) * 1.4,
      wobble: random() * Math.PI * 2,
    }));
    const sparks = Array.from({ length: SPARKS }, () => ({
      s: random(),
      phase: random() * Math.PI * 2,
      size: 0.6 + random() * 1.6,
      twinkle: 0.6 + random() * 1.8,
      drift: (random() - 0.5) * 18,
    }));

    let scale = 1;
    let frame = 0;
    let running = false;
    let visible = true;
    let last = 0;
    let time = 0;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.round(rect.width * ratio));
      canvas.height = Math.max(1, Math.round(rect.height * ratio));
      scale = Math.min(rect.width / VIEW.width, rect.height / VIEW.height);
      const offsetX = (rect.width - VIEW.width * scale) / 2;
      const offsetY = (rect.height - VIEW.height * scale) / 2;
      context.setTransform(ratio * scale, 0, 0, ratio * scale, ratio * offsetX, ratio * offsetY);
    };

    const draw = () => {
      context.save();
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.restore();

      context.globalCompositeOperation = "lighter";
      context.lineWidth = 0.75 / scale;
      context.lineCap = "butt";

      const chunkSize = Math.ceil(SAMPLES / CHUNKS);
      for (const strand of strands) {
        const phase = strand.phase + time * 0.35;
        for (let chunk = 0; chunk < CHUNKS; chunk++) {
          const start = chunk * chunkSize;
          const end = Math.min(SAMPLES - 1, start + chunkSize);
          const middle = (start + end) / 2 / (SAMPLES - 1);
          // Strands on the "front" of the twisted ribbon read brighter.
          const depth = Math.cos(phase + middle * strand.twist * Math.PI * 2);
          // Where the ribbon narrows, strands pile up; dim them so the coil keeps its color.
          const density = Math.min(1, (widths[Math.round(middle * (SAMPLES - 1))] + 4) / 34);
          context.strokeStyle = colorAt(middle, (0.06 + 0.38 * Math.pow(0.5 + 0.5 * depth, 2)) * density);
          context.beginPath();
          for (let i = start; i <= end; i++) {
            const s = i / (SAMPLES - 1);
            const fan = strand.amplitude + 0.25 * Math.sin(s * 9 + strand.wobble + time * 0.5);
            const offset = widths[i] * fan * Math.sin(phase + s * strand.twist * Math.PI * 2);
            const x = points[i].x + normals[i].x * offset;
            const y = points[i].y + normals[i].y * offset;
            if (i === start) context.moveTo(x, y);
            else context.lineTo(x, y);
          }
          context.stroke();
        }
      }

      for (const spark of sparks) {
        const i = Math.round(spark.s * (SAMPLES - 1));
        const offset = (widths[i] + spark.drift) * Math.sin(spark.phase + time * 0.2);
        const x = points[i].x + normals[i].x * offset;
        const y = points[i].y + normals[i].y * offset;
        const alpha = 0.35 + 0.55 * (0.5 + 0.5 * Math.sin(time * spark.twinkle + spark.phase));
        context.fillStyle = colorAt(Math.min(1, spark.s + 0.15), alpha);
        context.beginPath();
        context.arc(x, y, spark.size / scale, 0, Math.PI * 2);
        context.fill();
      }
    };

    const tick = (now: number) => {
      if (!running) return;
      const delta = last ? Math.min(0.05, (now - last) / 1000) : 0;
      last = now;
      time += delta;
      draw();
      frame = requestAnimationFrame(tick);
    };

    const sync = () => {
      const shouldRun = visible && !reducedMotion.matches && !document.hidden;
      if (shouldRun && !running) {
        running = true;
        last = 0;
        frame = requestAnimationFrame(tick);
      } else if (!shouldRun && running) {
        running = false;
        cancelAnimationFrame(frame);
      }
      if (!running) draw();
    };

    const resizeObserver = new ResizeObserver(() => {
      resize();
      draw();
    });
    resizeObserver.observe(canvas);

    const intersectionObserver = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      sync();
    });
    intersectionObserver.observe(canvas);

    reducedMotion.addEventListener("change", sync);
    document.addEventListener("visibilitychange", sync);
    resize();
    sync();

    return () => {
      running = false;
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      intersectionObserver.disconnect();
      reducedMotion.removeEventListener("change", sync);
      document.removeEventListener("visibilitychange", sync);
    };
  }, []);

  return <canvas ref={canvasRef} aria-hidden="true" className={cn("block aspect-[600/440] w-full", className)} />;
}
