"use client";

import { useId, useRef, useState, type KeyboardEvent } from "react";
import { BadgeCheck, CircleSlash } from "lucide-react";

import { SectionHeading } from "@/components/SectionHeading";
import { comparison } from "@/content/site";
import { cn } from "@/lib/utils";

export function Comparison() {
  const [active, setActive] = useState(0);
  const tabsRef = useRef<(HTMLButtonElement | null)[]>([]);
  const baseId = useId();
  const row = comparison.rows[active];

  const select = (index: number) => {
    const next = (index + comparison.rows.length) % comparison.rows.length;
    setActive(next);
    tabsRef.current[next]?.focus();
  };

  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "ArrowRight" || event.key === "ArrowDown") {
      event.preventDefault();
      select(active + 1);
    } else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
      event.preventDefault();
      select(active - 1);
    } else if (event.key === "Home") {
      event.preventDefault();
      select(0);
    } else if (event.key === "End") {
      event.preventDefault();
      select(comparison.rows.length - 1);
    }
  };

  return (
    <section aria-labelledby={comparison.id} className="mx-auto max-w-screen-xl px-5 sm:px-8">
      <div className="border-t border-border py-16 lg:py-24">
        <SectionHeading
          id={comparison.id}
          eyebrow={comparison.eyebrow}
          title={comparison.title}
          lead={comparison.lead}
        />

        <div className="mt-12 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-5 lg:mt-14">
          <p className="eyebrow shrink-0 text-muted-foreground">{comparison.aspectsLabel}</p>
          <div
            role="tablist"
            aria-label={comparison.caption}
            onKeyDown={onKeyDown}
            className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0 sm:pb-0"
          >
            {comparison.rows.map((item, index) => (
              <button
                key={item.aspect}
                ref={(element) => {
                  tabsRef.current[index] = element;
                }}
                id={`${baseId}-tab-${index}`}
                type="button"
                role="tab"
                aria-selected={index === active}
                aria-controls={`${baseId}-panel`}
                tabIndex={index === active ? 0 : -1}
                onClick={() => setActive(index)}
                className={cn(
                  "shrink-0 rounded-full border px-4 py-2 text-[0.9rem] transition-colors",
                  index === active
                    ? "border-foreground bg-foreground text-background"
                    : "border-border text-foreground hover:border-foreground/50",
                )}
              >
                {item.aspect}
              </button>
            ))}
          </div>
        </div>

        <div
          id={`${baseId}-panel`}
          role="tabpanel"
          aria-labelledby={`${baseId}-tab-${active}`}
          className="mt-6 grid gap-5 md:grid-cols-2"
        >
          {/* Typical bridge */}
          <article className="flex flex-col rounded-panel bg-muted p-6 sm:p-8">
            <header className="flex items-center justify-between gap-4">
              <h3 className="eyebrow text-muted-foreground">{comparison.columns.bridge}</h3>
              <CircleSlash className="size-5 text-muted-foreground" aria-hidden="true" />
            </header>
            <BridgeDiagram className="mt-6 w-full" />
            <p className="mt-4 text-[0.92rem] text-muted-foreground">{comparison.diagrams.bridge.caption}</p>
            <div className="mt-6 border-t border-foreground/10 pt-6">
              <p className="text-[0.8rem] text-muted-foreground">{row.aspect}</p>
              <p key={`bridge-${active}`} className="fade-up mt-2 text-2xl font-light leading-snug tracking-[-0.01em] text-foreground/75">
                {row.bridge}
              </p>
            </div>
          </article>

          {/* CLPR */}
          <article className="relative isolate flex flex-col overflow-hidden rounded-panel bg-night p-6 text-white sm:p-8">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -right-24 -top-24 -z-10 size-80 rounded-full bg-violet/40 blur-[90px]"
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-28 -left-16 -z-10 size-72 rounded-full bg-magenta/30 blur-[90px]"
            />
            <header className="flex items-center justify-between gap-4">
              <h3 className="eyebrow text-white">{comparison.columns.clpr}</h3>
              <BadgeCheck className="size-5 text-proof-glow" aria-hidden="true" />
            </header>
            <ClprDiagram className="mt-6 w-full" />
            <p className="mt-4 text-[0.92rem] text-night-text">{comparison.diagrams.clpr.caption}</p>
            <div className="mt-6 border-t border-white/15 pt-6">
              <p className="text-[0.8rem] text-white/55">{row.aspect}</p>
              <p key={`clpr-${active}`} className="fade-up mt-2 text-2xl font-light leading-snug tracking-[-0.01em]">
                {row.clpr}
              </p>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

function LedgerNode({ x, label, fill, stroke, text }: { x: number; label: string; fill: string; stroke?: string; text: string }) {
  return (
    <g>
      <circle cx={x} cy="66" r="26" fill={fill} stroke={stroke} strokeWidth={stroke ? 1.5 : 0} />
      <text x={x} y="71" textAnchor="middle" fontSize="15" fill={text}>
        {label.slice(-1)}
      </text>
      <text x={x} y="118" textAnchor="middle" fontSize="11.5" fill={text} opacity="0.7">
        {label}
      </text>
    </g>
  );
}

function BridgeDiagram({ className }: { className?: string }) {
  const { diagrams } = comparison;
  return (
    <svg viewBox="0 0 400 132" fill="none" aria-hidden="true" className={className}>
      <defs>
        <marker id="bridge-arrow" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="7" markerHeight="7" orient="auto">
          <path d="M0 0 8 4 0 8z" fill="var(--ink-soft)" />
        </marker>
      </defs>
      <line x1="76" y1="66" x2="136" y2="66" stroke="var(--ink-soft)" strokeWidth="1.5" markerEnd="url(#bridge-arrow)" />
      <line x1="264" y1="66" x2="322" y2="66" stroke="var(--ink-soft)" strokeWidth="1.5" markerEnd="url(#bridge-arrow)" />

      <rect x="140" y="24" width="120" height="84" rx="14" fill="var(--surface)" stroke="var(--ink-soft)" strokeDasharray="4 4" />
      <text x="200" y="54" textAnchor="middle" fontSize="15" fill="var(--ink)">
        {diagrams.bridge.middle}
      </text>
      <text x="200" y="72" textAnchor="middle" fontSize="9.5" fill="var(--ink-soft)">
        {diagrams.bridge.middleNote}
      </text>
      {[0, 1, 2, 3, 4].map((index) => (
        <circle key={index} cx={172 + index * 14} cy="90" r="4" fill="var(--ink-soft)" opacity={0.35 + index * 0.12} />
      ))}

      <LedgerNode x={48} label={diagrams.ledgerA} fill="var(--surface)" stroke="var(--line-strong)" text="var(--ink)" />
      <LedgerNode x={352} label={diagrams.ledgerB} fill="var(--surface)" stroke="var(--line-strong)" text="var(--ink)" />
    </svg>
  );
}

function ClprDiagram({ className }: { className?: string }) {
  const { diagrams } = comparison;
  return (
    <svg viewBox="0 0 400 132" fill="none" aria-hidden="true" className={className}>
      <defs>
        <linearGradient id="clpr-ledger-a" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--signal-glow)" />
          <stop offset="1" stopColor="var(--violet)" />
        </linearGradient>
        <linearGradient id="clpr-ledger-b" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--proof-glow)" />
          <stop offset="1" stopColor="var(--plum)" />
        </linearGradient>
      </defs>

      <line
        x1="80"
        y1="66"
        x2="320"
        y2="66"
        stroke="var(--signal-glow)"
        strokeWidth="3"
        strokeLinecap="round"
        strokeDasharray="0.01 9"
      />

      {/* The proof travels straight from ledger to ledger. */}
      <g className="proof-travel">
        <rect x="152" y="53" width="96" height="26" rx="13" fill="var(--night)" stroke="var(--proof-glow)" strokeWidth="1.5" />
        <text x="200" y="70" textAnchor="middle" fontSize="11" fill="var(--proof-glow)">
          {diagrams.clpr.proof}
        </text>
      </g>

      <LedgerNode x={48} label={diagrams.ledgerA} fill="url(#clpr-ledger-a)" text="white" />
      <LedgerNode x={352} label={diagrams.ledgerB} fill="url(#clpr-ledger-b)" text="white" />
    </svg>
  );
}
