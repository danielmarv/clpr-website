import { SectionHeading } from "@/components/SectionHeading";
import { layers } from "@/content/site";
import { cn } from "@/lib/utils";

export function Layers() {
  return (
    <section aria-labelledby={layers.id} className="mx-auto max-w-screen-xl px-5 sm:px-8">
      <div className="grid gap-12 rounded-panel bg-night px-5 py-12 text-white sm:px-10 sm:py-14 lg:grid-cols-12 lg:gap-16 lg:px-14 lg:py-20">
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <SectionHeading id={layers.id} eyebrow={layers.eyebrow} title={layers.title} lead={layers.lead} inverse />
          </div>
        </div>

        <ol className="lg:col-span-7" aria-label="CLPR protocol layers, from top to bottom">
          {layers.items.map((layer, index) => {
            const isApplication = index === 0;
            return (
              <li data-motion-reveal key={layer.name}>
                <div
                  className={cn(
                    "grid gap-3 border-x border-t border-night-line px-5 py-6 sm:grid-cols-[11rem_1fr] sm:gap-6 sm:px-6",
                    index === 0 && "rounded-t-lg",
                    index === layers.items.length - 1 && "rounded-b-lg border-b",
                    isApplication && "bg-ember border-transparent",
                  )}
                >
                  <h3 className="text-xl font-normal leading-tight">{layer.name}</h3>
                  <div>
                    <p className={isApplication ? "text-white/85" : "text-night-text"}>{layer.body}</p>
                    <ul className="mt-4 flex flex-wrap gap-2" aria-label={`Key terms in the ${layer.name} layer`}>
                      {layer.terms.map((term) => (
                        <li
                          key={term}
                          className={cn(
                            "rounded-full border px-3 py-0.5 text-[0.82rem]",
                            isApplication ? "border-white/40 text-white" : "border-night-line text-white/85",
                          )}
                        >
                          {term}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* The Application API boundary sits between the top layer and the rest. */}
                {isApplication && (
                  <div className="relative border-x border-night-line" aria-hidden="true">
                    <div className="h-px bg-magenta" />
                    <span className="eyebrow absolute right-4 top-0 -translate-y-1/2 bg-night px-2 text-[0.72rem] text-proof-glow sm:right-6">
                      {layers.apiNote}
                    </span>
                  </div>
                )}
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
