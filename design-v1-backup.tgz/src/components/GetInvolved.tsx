import { ArrowRight, Code2, FileText, Network, type LucideIcon } from "lucide-react";

import { SectionHeading } from "@/components/SectionHeading";
import { SpiralRibbon } from "@/components/SpiralRibbon";
import { Button } from "@/components/ui/button";
import { involvement } from "@/content/site";

// One icon per path, in the order they appear in the content.
const pathIcons: LucideIcon[] = [FileText, Code2, Network];

export function GetInvolved() {
  return (
    <section aria-labelledby={involvement.id} className="mx-auto max-w-screen-xl px-5 sm:px-8">
      <div className="border-t border-border pb-16 pt-16 lg:pb-24 lg:pt-24">
        <SectionHeading
          id={involvement.id}
          eyebrow={involvement.eyebrow}
          title={involvement.title}
          lead={involvement.lead}
        />

        <ul className="mt-12 grid gap-4 md:grid-cols-3 lg:mt-16">
          {involvement.paths.map((path, index) => {
            const Icon = pathIcons[index] ?? FileText;
            return (
              <li data-motion-reveal key={path.name}>
                <a
                  href={path.href}
                  target="_blank"
                  rel="noreferrer"
                  className="group relative isolate flex h-full flex-col overflow-hidden rounded-panel border border-border bg-card p-6 transition-[border-color,box-shadow,transform] duration-300 hover:-translate-y-1 hover:border-transparent hover:shadow-[0_30px_60px_-30px_rgb(63_34_215/0.5)] sm:p-7"
                >
                  {/* Gradient wash revealed on hover */}
                  <span
                    aria-hidden="true"
                    className="absolute inset-0 -z-10 bg-gradient-to-br from-signal-wash via-card to-proof-wash opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                  />
                  <div className="flex items-center justify-between">
                    <span className="bg-ember flex size-12 items-center justify-center rounded-full text-white shadow-[0_10px_24px_-10px_var(--magenta)]">
                      <Icon className="size-5" strokeWidth={1.75} aria-hidden="true" />
                    </span>
                    <span className="text-sm tabular-nums text-muted-foreground" aria-hidden="true">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                  </div>
                  <h3 className="mt-8 text-2xl font-normal leading-snug tracking-[-0.01em]">{path.name}</h3>
                  <p className="mt-3 flex-1 text-muted-foreground">{path.body}</p>
                  <span className="mt-8 inline-flex items-center gap-2 font-medium">
                    {path.cta}
                    <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
                  </span>
                </a>
              </li>
            );
          })}
        </ul>

        <div data-motion-reveal className="bg-aurora relative mt-16 overflow-hidden rounded-panel text-white lg:mt-20">
          <div className="grid items-center lg:grid-cols-12">
            <div className="relative z-10 px-6 py-12 sm:px-10 sm:py-14 lg:col-span-6 lg:py-20 lg:pl-14 lg:pr-0">
              <p className="text-[clamp(2rem,3.6vw,3rem)] font-light leading-[1.1] tracking-[-0.035em]">
                {involvement.closing.title}
              </p>
              <p className="mt-4 max-w-md text-lg text-white/85">{involvement.closing.body}</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button asChild size="lg" variant="glass">
                  <a href={involvement.closing.primary.href} target="_blank" rel="noreferrer">
                    {involvement.closing.primary.label}
                  </a>
                </Button>
                <Button asChild size="lg" variant="inverse-outline">
                  <a href={involvement.closing.secondary.href} target="_blank" rel="noreferrer">
                    {involvement.closing.secondary.label}
                  </a>
                </Button>
              </div>
            </div>
            <div className="-mb-10 -mt-6 px-4 lg:col-span-6 lg:-my-6 lg:px-0 lg:pr-6">
              <SpiralRibbon />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
