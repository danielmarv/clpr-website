import { cn } from "@/lib/utils";

export function SectionHeading({
  id,
  eyebrow,
  title,
  lead,
  inverse = false,
  className,
}: {
  id?: string;
  eyebrow?: string;
  title: string;
  lead?: string;
  inverse?: boolean;
  className?: string;
}) {
  return (
    <div data-motion-reveal className={cn("max-w-3xl", className)}>
      {eyebrow && <p className={cn("eyebrow mb-4", inverse ? "text-white" : "text-foreground")}>{eyebrow}</p>}
      <h2
        id={id}
        className="text-[clamp(1.9rem,3.6vw,2.75rem)] font-normal leading-[1.14] tracking-[-0.02em] text-balance"
      >
        {title}
      </h2>
      {lead && (
        <p
          className={cn(
            "mt-6 max-w-[64ch] text-lg leading-[1.75]",
            inverse ? "text-night-text" : "text-muted-foreground",
          )}
        >
          {lead}
        </p>
      )}
    </div>
  );
}
