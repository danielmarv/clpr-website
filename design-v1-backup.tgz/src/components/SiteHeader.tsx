"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";

import { ClprMark } from "@/components/ClprMark";
import { GitHubMark } from "@/components/GitHubMark";
import { Button } from "@/components/ui/button";
import { links, nav, site } from "@/content/site";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  // Transparent over the hero gradient, solid once the page scrolls.
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-40 text-white transition-colors duration-300",
        scrolled || open ? "bg-night/95 backdrop-blur-md" : "bg-transparent",
      )}
    >
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-50 focus:rounded-full focus:bg-white focus:px-4 focus:py-2 focus:text-night"
      >
        {site.skipLink}
      </a>

      <div className="mx-auto flex h-18 max-w-screen-xl items-center gap-6 px-5 sm:px-8">
        <Link
          href="/"
          aria-label={site.homeLabel}
          className="flex items-center gap-3"
          onClick={() => setOpen(false)}
        >
          <ClprMark className="h-6" />
          <span className="text-[1.375rem] font-medium tracking-[-0.01em]">{site.name}</span>
        </Link>

        <nav aria-label="Main" className="ml-auto hidden md:block">
          <ul className="flex items-center gap-1">
            {nav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  className="rounded-full px-3.5 py-2 text-[0.9375rem] text-white/85 transition-colors hover:text-white"
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <Button asChild variant="inverse-outline" size="sm" className="ml-auto hidden md:ml-2 md:inline-flex">
          <a href={links.githubOrg} target="_blank" rel="noreferrer">
            <GitHubMark />
            {site.githubLabel}
          </a>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="ml-auto text-white hover:bg-white/10 md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? site.menuClose : site.menuOpen}
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X /> : <Menu />}
        </Button>
      </div>

      {open && (
        <nav id="mobile-menu" aria-label="Main" className="border-t border-white/10 px-5 pb-6 pt-2 md:hidden">
          <ul className="flex flex-col">
            {nav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="block border-b border-white/10 py-3.5 text-lg"
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
          <Button asChild variant="inverse-outline" className="mt-5 w-full">
            <a href={links.githubOrg} target="_blank" rel="noreferrer">
              <GitHubMark />
              {site.githubLabel}
            </a>
          </Button>
        </nav>
      )}
    </header>
  );
}
