import Link from "next/link";

import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <>
      <SiteHeader />
      <main id="main" className="bg-aurora text-white">
        <div className="mx-auto max-w-screen-xl px-5 pb-28 pt-40 sm:px-8">
          <p className="eyebrow text-white/70">404</p>
          <h1 className="mt-4 max-w-[18ch] text-[clamp(2.4rem,5.5vw,4rem)] font-light leading-[1.1] tracking-[-0.04em]">
            This page never made it across.
          </h1>
          <p className="mt-6 max-w-[56ch] text-lg text-white/85">
            The address may be mistyped, or the page may have moved. The home page links to everything on this site.
          </p>
          <Button asChild size="lg" variant="glass" className="mt-10">
            <Link href="/">Go to the home page</Link>
          </Button>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
