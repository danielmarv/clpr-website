import { Comparison } from "@/components/Comparison";
import { Extensibility } from "@/components/Extensibility";
import { GetInvolved } from "@/components/GetInvolved";
import { Glossary } from "@/components/Glossary";
import { Hero } from "@/components/Hero";
import { Layers } from "@/components/Layers";
import { Repositories } from "@/components/Repositories";
import { Roadmap } from "@/components/Roadmap";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteMotion } from "@/components/SiteMotion";
import { Walkthrough } from "@/components/Walkthrough";

export default function HomePage() {
  return (
    <SiteMotion>
      <SiteHeader />
      <main id="main" className="home-background">
        <Hero />
        <Walkthrough />
        <Comparison />
        <Layers />
        <Extensibility />
        <Repositories />
        <Glossary />
        <Roadmap />
        <GetInvolved />
      </main>
      <SiteFooter />
    </SiteMotion>
  );
}
